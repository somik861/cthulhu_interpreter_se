# Instr

Does not belong to any instruction group (apart from generic)


Special operations:
```
noop 
    # literally does nothing :D, this 'zero' instruction
```