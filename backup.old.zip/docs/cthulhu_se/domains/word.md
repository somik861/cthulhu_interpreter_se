# Word

Operation groups:
* Generatble
* Arithmetic
* Equitable
* Orderable
* Guardable
* Logical
