#pragma once

namespace cthu::interpreter {
enum class Mode { Debug, Normal, Fast, Parallel };
}
