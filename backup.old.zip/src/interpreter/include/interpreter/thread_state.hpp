#pragma once

namespace cthu::interpreter {
enum class ThreadState { Running, Finished, Killed };
}